async function loadProducts(){
  const res = await fetch('/api/products');
  const products = await res.json();
  const container = document.getElementById('products');
  container.innerHTML = products.map(p => `
    <article class="card">
      <img src="${p.image ? '/uploads/'+p.image : 'https://via.placeholder.com/400x300'}" alt="${p.title}">
      <h3>${p.title}</h3>
      <div class="price">${p.price} ₴</div>
      <p>${p.description || ''}</p>
      <button class="buy" onclick="alert('Добавлено в корзину (демо)')">Купить</button>
    </article>
  `).join('');
}
loadProducts();