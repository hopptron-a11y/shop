let token = null;
document.getElementById('login-btn').addEventListener('click', async ()=>{
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;
  const res = await fetch('/api/login', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({username,password})
  });
  const data = await res.json();
  if(res.ok){ token = data.token; document.getElementById('login-section').style.display='none'; document.getElementById('admin-section').style.display='block'; loadItems(); }
  else alert(data.message || 'Ошибка');
});

async function loadItems(){
  const res = await fetch('/api/products', { headers: token ? {Authorization:'Bearer '+token} : {} });
  const list = await res.json();
  const container = document.getElementById('items-list');
  container.innerHTML = list.map(p => `
    <div class="card">
      <img src="${p.image?'/uploads/'+p.image:'https://via.placeholder.com/200x140'}" style="height:100px" />
      <h4>${p.title} — ${p.price} ₴</h4>
      <p>${p.description||''}</p>
      <button onclick="deleteItem(${p.id})">Удалить</button>
    </div>
  `).join('');
}

async function deleteItem(id){
  if(!confirm('Удалить товар?')) return;
  await fetch('/api/products/'+id, { method:'DELETE', headers:{ Authorization:'Bearer '+token } });
  loadItems();
}

document.getElementById('product-form').addEventListener('submit', async (e)=>{
  e.preventDefault();
  const form = e.target;
  const formData = new FormData(form);
  const res = await fetch('/api/products', { method:'POST', body: formData, headers: token ? { Authorization:'Bearer '+token } : {} });
  if(res.ok){ alert('Товар добавлен'); form.reset(); loadItems(); }
  else { const err = await res.json(); alert(err.message||'Ошибка'); }
});