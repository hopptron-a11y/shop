const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const bodyParser = require('body-parser');
const multer = require('multer');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
const db = new sqlite3.Database('./db.sqlite');

app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));
app.use('/uploads', express.static('public/uploads'));

const upload = multer({ dest: 'public/uploads/' });

db.serialize(()=>{
  db.run(`CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT,
    price REAL NOT NULL,
    image TEXT
  )`);
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password_hash TEXT
  )`, ()=>{
    db.get("SELECT * FROM users WHERE username = 'admin'", (err,row)=>{
      if(!row){
        const hash = bcrypt.hashSync('admin123', 10);
        db.run("INSERT INTO users (username,password_hash) VALUES (?,?)", ['admin', hash]);
        console.log('Created default admin / password: admin123');
      }
    });
  });
});

const JWT_SECRET = 'change_me_to_secure_secret';

app.post('/api/login', (req,res)=>{
  const { username, password } = req.body;
  db.get('SELECT * FROM users WHERE username = ?', [username], (err, user) => {
    if(err || !user) return res.status(401).json({ message: 'Неверные данные' });
    if(!bcrypt.compareSync(password, user.password_hash)) return res.status(401).json({ message: 'Неверные данные' });
    const token = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: '8h' });
    res.json({ token });
  });
});

function authMiddleware(req,res,next){
  const auth = req.headers.authorization;
  if(!auth) return res.status(401).json({ message: 'Нет авторизации' });
  const token = auth.split(' ')[1];
  try{
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  }catch(e){ return res.status(401).json({ message: 'Неверный токен' }); }
}

app.get('/api/products', (req,res)=>{
  db.all('SELECT * FROM products ORDER BY id DESC', (err,rows)=> {
    if(err) return res.status(500).json([]);
    res.json(rows);
  });
});

app.post('/api/products', authMiddleware, upload.single('image'), (req,res)=>{
  const { title, description, price } = req.body;
  const image = req.file ? req.file.filename : null;
  db.run('INSERT INTO products (title,description,price,image) VALUES (?,?,?,?)', [title,description,price,image], function(err){
    if(err) return res.status(500).json({ message:'Ошибка БД' });
    res.json({ id: this.lastID });
  });
});

app.delete('/api/products/:id', authMiddleware, (req,res)=>{
  const id = req.params.id;
  db.run('DELETE FROM products WHERE id = ?', [id], function(err){
    if(err) return res.status(500).json({ message:'Ошибка' });
    res.json({ deleted: this.changes });
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=> console.log('Server started on', PORT));